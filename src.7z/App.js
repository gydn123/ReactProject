import "./App.css";
import Promotion from "./component/Promotion";

function App() {
  return (
    <div className="App">
      <Promotion />
    </div>
  );
}

export default App;
