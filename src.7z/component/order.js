import React, { useState, useEffect } from "react";
import { Container, Form, Table, Button } from "react-bootstrap";

const ProductForm = ({ data, onDataSubmit }) => {
  const [numValues, setNumValues] = useState(Array(data.length).fill(0));
  const [totals, setTotals] = useState(Array(data.length).fill(0));
  const [sum, setSum] = useState(0);
  const [usedPoints, setUsedPoints] = useState(0);

  const handleMinusClick = (idx) => {
    if (numValues[idx] > 0) {
      const updatedNumValues = [...numValues];
      updatedNumValues[idx] -= 1;
      setNumValues(updatedNumValues);

      const updatedTotals = [...totals];
      updatedTotals[idx] =
        data[idx].ticket_price *
        (1 - data[idx].discount) *
        updatedNumValues[idx];
      setTotals(updatedTotals);
    }
  };

  const handlePlusClick = (idx) => {
    if (numValues[idx] < 10) {
      const updatedNumValues = [...numValues];
      updatedNumValues[idx] += 1;
      setNumValues(updatedNumValues);

      const updatedTotals = [...totals];
      updatedTotals[idx] =
        data[idx].ticket_price *
        (1 - data[idx].discount) *
        updatedNumValues[idx];
      setTotals(updatedTotals);
    }
  };

  useEffect(() => {
    setSum(totals.reduce((acc, curr) => acc + curr, 0));
  }, [totals]);

  const handleBuyClick = () => {
    if (onDataSubmit) {
      // 여기서 서버에 데이터를 전송하거나 다음 단계로 데이터를 보낸다.
      onDataSubmit(numValues, usedPoints);
    }
  };

  const handlePointChange = (e) => {
    const points = parseInt(e.target.value);
    if (points >= 0 && points <= data[0].sum_point) {
      setUsedPoints(points);
    }
  };

  return (
    <Container>
      <Form>
        <div className="product">
          {/*<img src={data[0].promotion_img} alt="Product Image" />*/}
          <div>
            <div className="name">{data[0].promotion_name}</div>
            <div className="description">{data[0].promotion_content}</div>
          </div>
        </div>
        <Table>
          <thead>
            <tr>
              <th>행사명</th>
              <th>상품명</th>
              <th>가격</th>
              <th>수량</th>
              <th>합계</th>
            </tr>
          </thead>
          <tbody>
            {data.map((d, idx) => (
              <tr key={d.ticket_id} className="table-row">
                <td>{d.promotion_name}</td>
                <td>{d.ticket_name}</td>
                <td className="price">{d.ticket_price * (1 - d.discount)}₩</td>
                <td>
                  <Button
                    variant="secondary"
                    type="button"
                    className="minus"
                    onClick={() => handleMinusClick(idx)}
                  >
                    -
                  </Button>{" "}
                  <input
                    type="number"
                    className="numbox"
                    value={numValues[idx]}
                    readOnly
                  />{" "}
                  <input
                    type="hidden"
                    className="ticket-id"
                    value={d.ticket_id}
                  />
                  <Button
                    variant="secondary"
                    type="button"
                    className="plus"
                    onClick={() => handlePlusClick(idx)}
                  >
                    +
                  </Button>
                </td>
                <td className="total">{totals[idx]}₩</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="totalsum">
              <td>총 가격 :</td>
              <td>
                <input
                  type="number"
                  className="mt-4 mb-4"
                  id="sum"
                  value={sum}
                  readOnly
                />
              </td>
              <td>포인트 사용 :</td>
              <td>
                <input
                  type="number"
                  className="mt-4 mb-4"
                  id="mypoint"
                  value={usedPoints}
                  max={data[0].sum_point}
                  min="0"
                  onChange={handlePointChange}
                />
              </td>
              <td>
                <Button
                  id="buy-btn"
                  type="button"
                  className="mt-4 mb-4"
                  style={{ float: "right" }}
                  onClick={handleBuyClick}
                >
                  구매 하기
                </Button>
              </td>
            </tr>
          </tfoot>
        </Table>
      </Form>
    </Container>
  );
};

export default ProductForm;
