package com.exciting.dto;

import lombok.Data;

@Data
public class AimageDTO {
	private int aimg_id;
	private String aimg_name;
	private int amuse_id;
	private String url;
}
