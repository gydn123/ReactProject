package com.exciting.amuse.service;

import java.util.List;
import java.util.Map;

import com.exciting.dto.AimageDTO;

public interface AmuseImageService {
	public List<AimageDTO> aImgList(Map<String, Object> map);
}
